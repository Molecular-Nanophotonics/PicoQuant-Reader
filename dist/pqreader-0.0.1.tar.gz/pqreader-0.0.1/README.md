# PicoQuant-Reader
Module for reading files from PicoQuant TimeHarp 200 in Python
