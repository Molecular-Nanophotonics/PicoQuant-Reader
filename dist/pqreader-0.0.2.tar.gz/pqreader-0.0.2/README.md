# PicoQuant Reader
Package for reading files from PicoQuant TimeHarp 200.

[Molecular Nanophotonics Group](http://www.uni-leipzig.de/~mona)
