# PicoQuant Reader
Package for reading biniary files from PicoQuant TimeHarp 200.

[Documentation](http://molecular-nanophotonics.github.io/pqreader)

<<<<<<< HEAD
<img src="https://github.com/Molecular-Nanophotonics/pqreader/blob/master/images/TimeHarp_200.png" width="500"/>
=======
<img src="https://github.com/Molecular-Nanophotonics/pqreader/blob/master/resources/TimeHarp_200_01.png" width="500"/>
>>>>>>> a0b1a0afca90583c57e03b74b041f2d98b99826c

[Molecular Nanophotonics Group](http://www.uni-leipzig.de/~mona), Leipzig University
